from setuptools import setup, find_packages

setup(
    name="books_databricks",  # Replace with your package name
    version="0.1.0",
    author="nastyakononovaa76@gmail.com",
    packages=find_packages(),
    install_requires=[
        
    ],
    python_requires=">=3.6",
)